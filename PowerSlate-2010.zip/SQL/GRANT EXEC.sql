USE [Campus6]
GRANT EXEC ON [custom].[PS_selISIR] TO PowerSlate
GRANT EXEC ON [custom].[PS_updDemographics] TO PowerSlate
GRANT EXEC ON [custom].[PS_updAcademicAppInfo] TO PowerSlate
GRANT EXEC ON [custom].[PS_updAction] to PowerSlate
GRANT EXEC ON [custom].[PS_selProfile] to PowerSlate
GRANT EXEC ON [custom].[PS_selRAStatus] to PowerSlate
GRANT EXEC ON [custom].[PS_updSMSOptIn] to PowerSlate
