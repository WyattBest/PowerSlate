﻿python.exe .\sync_http.py config_sample.json
